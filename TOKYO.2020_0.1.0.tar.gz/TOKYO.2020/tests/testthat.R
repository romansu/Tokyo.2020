library(testthat)
library(TOKYO.2020)

test_check("TOKYO.2020")
